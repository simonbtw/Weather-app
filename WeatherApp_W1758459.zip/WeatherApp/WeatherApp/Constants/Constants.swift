//
//  Constants.swift
//  WeatherApp
//
//  Created by Simon Ibrahim on 19/05/2022.
//

import Foundation
let openWeatherApi = "0fc69da2f27bf0e58916624e7e4b18e0"
let baseURL = "https://api.openweathermap.org/data/2.5/weather?appid=\(openWeatherApi)&q="

func getWeatherIconUrl(icon:String) -> URL{
    guard let url = URL(string: "https://openweathermap.org/img/w/\(icon).png")
    else{
        fatalError("Invalid url")
    }
    return url
}
func convertKalvinToCelsius(value:Double)->Double
{
    return value - 273.15
}

struct ImageNames{
    static let humidity = "humidity.fill"
    static let temp = "thermometer"
    static let wind = "wind"
    static let clouds = "cloud.fill"
    static let bg = "BG"
}
