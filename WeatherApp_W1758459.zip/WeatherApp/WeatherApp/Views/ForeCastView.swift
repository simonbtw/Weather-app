//
//  ForeCastView.swift
//  WeatherApp
//
//  Created by Simon Ibrahim on 20/05/2022.
//

import SwiftUI
import Combine
struct ForeCastView:View{
    // Observed varible
    @ObservedObject private var foreCastViewModel = ForecastViewModel()
    
    var coordinate:Coord
    var body: some View{
        ZStack{
            
            if foreCastViewModel.foreCastList.count > 0 {
                // Showing Results into List view
                List {
                    ForEach(foreCastViewModel.foreCastList) {
                        forcast in
                        ListCellView(forecastItem: forcast)
                    }
                }
            }else{
                //Showing Error Message if error occurs
                Text(foreCastViewModel.errorMessage)
                    .font(.largeTitle)
                    
            }
            
        }
        .background(Image(ImageNames.bg).ignoresSafeArea())
        .onAppear {
            UITableView.appearance().backgroundColor = .clear // For tableView
            UITableViewCell.appearance().backgroundColor = .clear
            
            // Calling Forecast Api with search city coordinates which passed from Mainweatherview
            foreCastViewModel.getForecasrReportByCoordinates(lat: coordinate.lat ?? 0.0, log: coordinate.lon ?? 0.0)
        }
    }
    
    
}
// Cell List View (UI)
struct ListCellView: View{
    var forecastItem:ListModel
    var body: some View{
        HStack(spacing:10){
            // AsyncImage download the image from url asynchronously and then show it to screen.
            AsyncImage(url: getWeatherIconUrl(icon: forecastItem.weather?.first?.icon ?? ""))
                .frame(width: 80, height: 80, alignment: .leading)
            
            //Collection of views from top-bottom position
            VStack{
                Text(forecastItem.weather?.first?.weatherDescription ?? "")
                    .font(.system(size: 17, weight: .medium, design: .default))
                    .lineLimit(0)
                Text(forecastItem.dtTxt ?? "")
                    .font(.system(size: 15, weight: .regular, design: .default))
                    .minimumScaleFactor(0.5)
                    .lineLimit(0)
            }.frame(maxWidth:.infinity,alignment: .leading)
            Text("°C \(Int(convertKalvinToCelsius(value:forecastItem.main?.temp ?? 0.0)))")
        }
        
        .frame(maxWidth:.infinity)
        .padding()
    }
}
