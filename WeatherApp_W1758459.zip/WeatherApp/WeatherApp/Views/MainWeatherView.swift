//
//  MainWeatherView.swift
//  WeatherApp
//
//  Created by Simon Ibrahim on 19/05/2022.
//

import SwiftUI
import Combine
struct MainWeatherView: View {
    @ObservedObject private var vm = MainWeatherViewModel()
    @State private var searchCity = ""
    
    var body: some View {
        NavigationView{
            VStack{
                // Horizontal View collection with TextField and search button
                HStack{
                    //Search TextField,searchCity is a state varibale.when user type something on textField it will store in searchCity Variable.
                    TextField(" Enter City Name", text: $searchCity)
                        .frame(height:46)
                        .background(RoundedRectangle(cornerRadius: 8).fill(Color.white))
                    //Search Button
                    Button(action: {
                        // Calling weather Api by name
                        vm.getWeatherReportByCityName(txt: searchCity)
                    }) {
                        Text("Search")
                    }
                }.padding(.all, 10)
                // If user pressed search button, showing spinner on UI
                if vm.isLoading{
                    ProgressView().progressViewStyle(CircularProgressViewStyle())
                }else{
                    //Showing Weather Data on UI by checking if weather data is not nil
                    if vm.weatherData != nil{
                        VStack(spacing:10){
                            // UI Stuff
                            WeatherDetailView(icon:nil, text:"\(Int(convertKalvinToCelsius(value: vm.weatherData?.main?.temp ?? 0.0))) °C", systemIcon: ImageNames.temp)
                            //UI Stuff
                            WeatherDetailView(icon: nil, text:"\(vm.weatherData?.main?.humidity ?? 0)", systemIcon: ImageNames.humidity)
                            
                            //User pressed this link, goes to DetailWeatherView.I am passing current weather data model on this Detail Weather View.
                            NavigationLink("Weather Details") {
                                DetailWeatherView(data: vm.weatherData)
                            }.foregroundColor(.black)
                            
                            Spacer().frame(height:10)
                            
                            // User pressed this link, goes to ForecastView. I am passing current searched city coordinates to forecast view.
                            NavigationLink("5 Day forescast") {
                                if let c = vm.weatherData?.coord{
                                    ForeCastView(coordinate: c)
                                }else{
                                    Text("Error")
                                }
                                
                            }.foregroundColor(.black)
                            
                        }
                    }
                    else{
                        //Showing Error Message if error occurs
                        Text(vm.errorMessage)
                            .font(.largeTitle)
                    }
                    
                }
                Spacer()
                
            }
            .background(Image(ImageNames.bg).ignoresSafeArea())
            .navigationTitle(vm.weatherData?.name ?? "Weather")
            .navigationViewStyle(.stack)
        }
    }
}

// UI Stuff (Showing Weather Results like Icon and Text on UI)
struct WeatherDetailView:View{
    let icon:String?
    let text:String
    let systemIcon:String?
    var body: some View{
        ZStack{
            HStack(spacing:10){
                Spacer()
                //Logic for showing remote Image or local image
                if systemIcon == nil {
                    // AsyncImage download the image from url asynchronously and then show it to screen.
                    AsyncImage(url:getWeatherIconUrl(icon: icon!))
                        .frame(width:80,height: 80,alignment: .center)
                }else{
                    // Regular Image with systemName
                    Image(systemName: systemIcon ?? "")
                        .frame(width:80,height: 80,alignment: .center)
                }
                Text(text).font(.headline)
                    .frame(maxWidth:.infinity,alignment:.center)
                Spacer()
            }.frame(maxWidth:200)
        }
    }
    
    
}

struct MainWeatherView_Previews: PreviewProvider {
    static var previews: some View {
        MainWeatherView()
    }
}
