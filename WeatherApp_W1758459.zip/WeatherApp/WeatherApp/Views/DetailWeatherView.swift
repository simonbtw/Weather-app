//
//  DetailWeatherView.swift
//  WeatherApp
//
//  Created by Simon Ibrahim on 20/05/2022.
//

import SwiftUI
struct DetailWeatherView:View{
    var data:WeatherModel?
    var body: some View{
        ZStack{
            VStack(spacing:10)
            {
                Text(data?.name ?? "")
                   
                    .font(.largeTitle)
                    .frame(alignment:.leading)
                
                AsyncImage(url: getWeatherIconUrl(icon: data?.weather?.first?.icon ?? ""))
                    .frame(alignment:.center)
                
                WeatherDetailView(icon: nil, text: "\(Int(convertKalvinToCelsius(value: data?.main?.temp ?? 0.0))) °C",systemIcon: ImageNames.temp)
                
                WeatherDetailView(icon: nil, text: "\(data?.main?.humidity ?? 0)", systemIcon:ImageNames.humidity)
                
                WeatherDetailView(icon: nil, text: "\(data?.wind?.speed ?? 0.0)", systemIcon:ImageNames.wind)
                Spacer()
            }.padding()
            
        }
        .background(Image(ImageNames.bg).ignoresSafeArea())
    }
}
