//
//  MainWeatherViewModel.swift
//  WeatherApp
//
//  Created by Simon Ibrahim on 19/05/2022.
//

import Foundation
import Network
import Combine
final class MainWeatherViewModel:ObservableObject{
    @Published var weatherData : WeatherModel?
    @Published var errorMessage = ""
    @Published var isLoading = false
    @Published var isSearchTapped = false
    private let monitor = NWPathMonitor()
    private let queue = DispatchQueue(label: "InternetConnectionMonitor")
    private var urlSession : URLSession
    init(){
        // configure the url session timeout and resource
        let sessionConfig = URLSessionConfiguration.default
        sessionConfig.timeoutIntervalForRequest = 30.0
        sessionConfig.timeoutIntervalForResource = 60.0
        urlSession = URLSession(configuration: sessionConfig)
        monitor.start(queue: queue)
        checkInternetConnection()
        
    }
    func getWeatherReportByCityName(txt:String)
    {
        // Checkig if search have text in it.
        guard !txt.isEmpty else {
            self.errorMessage = "Search field is empty."
            return
        }
        // Replacing space with %20.
        let str = txt.replacingOccurrences(of: " ", with: "%20")
        
        // Checking the url, if url invalid i am simply return from the function.
        guard let uri = URL(string: "\(baseURL)\(str)") else {
            self.errorMessage = "Invalid URL. Please Input correct URL."
            return
        }
        // For Showing spinner on view
        isLoading = true
        
        // URLSession is used for netwoking,means for downloading or fetching data from server, we use urlsession data task.
        urlSession.dataTask(with: uri) { data, response, error in
            if error != nil {
                DispatchQueue.main.async {
                    self.isLoading = false
                    self.weatherData = nil
                    self.errorMessage = error?.localizedDescription ?? ""
                }
            }else if let res = response as? HTTPURLResponse,
                     res.statusCode == 200
            {
                // we will use dispatch main queue if we need to update UI changes when we will on backgournd thread.
                DispatchQueue.main.async {
                    self.isLoading = false
                    self.isSearchTapped = false
                    guard let data = data else {
                        return
                        
                    }
                    do{
                        // Parsing Data into model
                        let weatherModel = try JSONDecoder().decode(WeatherModel.self, from: data)
                        debugPrint(weatherModel.coord)
                        self.weatherData = weatherModel
                    }catch {
                        // if any error occurs simply assigning the error.localizedDescription to error Message which updates the UI.
                        //
                        self.weatherData = nil
                        self.errorMessage = error.localizedDescription
                    }
                }
                
                
            }
            else{
                DispatchQueue.main.async {
                    self.isLoading = false
                    self.weatherData = nil
                    self.errorMessage = "No Data Found Relative to \(txt)"
                }
                
            }
        }.resume()
    }
    
    private func checkInternetConnection(){
        monitor.pathUpdateHandler = { pathUpdateHandler in
            if pathUpdateHandler.status == .satisfied {
                DispatchQueue.main.async {
                    //self.weatherData = nil
                    self.errorMessage = ""
                }
            }
            else if pathUpdateHandler.status == .requiresConnection{
                DispatchQueue.main.async {
                    //self.weatherData = nil
                    self.errorMessage = ""
                }
            }
            else {
                print("There's no internet connection.")
                DispatchQueue.main.async {
                    self.weatherData = nil
                    self.errorMessage = "There's no internet connection."
                }
                
            }
        }
    }
}
