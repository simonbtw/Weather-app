//
//  ForecastViewModel.swift
//  WeatherApp
//
//  Created by Simon Ibrahim on 20/05/2022.
//

import Foundation
import Combine
final class ForecastViewModel:ObservableObject{
    
    @Published var foreCastList = [ListModel]()
    @Published var errorMessage = ""
    @Published var isLoading = false
    private var urlSession : URLSession
    init(){
        // configure the url session timeout and resource
        let sessionConfig = URLSessionConfiguration.default
        sessionConfig.timeoutIntervalForRequest = 30.0
        sessionConfig.timeoutIntervalForResource = 60.0
        urlSession = URLSession(configuration: sessionConfig)
    }
    func getForecasrReportByCoordinates(lat:Double,log:Double)
    {
        guard let uri = URL(string: "https://api.openweathermap.org/data/2.5/forecast?lat=\(lat)&lon=\(log)&appid=\(openWeatherApi)") else {
            fatalError("Invalid url")
        }
        isLoading = true
        urlSession.dataTask(with: uri) { data, response, error in
            if error != nil {
                DispatchQueue.main.async {
                    self.isLoading = false
                    self.errorMessage = error?.localizedDescription ?? ""
                }
                
            }else if let res = response as? HTTPURLResponse,
                     res.statusCode == 200
            {
                DispatchQueue.main.async {
                    self.isLoading = false
                    guard let data = data else {return}
                    do{
                        let weatherModel = try JSONDecoder().decode(ForecastModel.self, from: data)
                        if let forList = weatherModel.list{
                            self.foreCastList = forList
                        }
                    }
                    catch {
                        self.foreCastList.removeAll()
                        self.errorMessage = error.localizedDescription
                    }
                }
                
                
            }
        }.resume()
    }
}

