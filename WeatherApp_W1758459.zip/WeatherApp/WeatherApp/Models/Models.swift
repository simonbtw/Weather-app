//
//  Models.swift
//  WeatherApp
//
//  Created by Simon Ibrahim on 19/05/2022.
//

import Foundation
struct WeatherModel: Codable {
    let coord: Coord?
    let weather: [Weather]?
    let base: String?
    let main: Main?
    let visibility: Int?
    let wind: Wind?
    //let clouds: Clouds?
    //let dt: Int?
    //let sys: Sys?
    let timezone, id: Int?
    let name: String?
    let cod: Int?
}

struct Clouds: Codable {
    let all: Int?
}

import Foundation

// MARK: - Coord
struct Coord: Codable {
    let lon, lat: Double?
}
// MARK: - Main
struct Main: Codable {
    let temp, feelsLike, tempMin, tempMax: Double?
    let pressure, humidity: Int?

    enum CodingKeys: String, CodingKey {
        case temp
        case feelsLike = "feels_like"
        case tempMin = "temp_min"
        case tempMax = "temp_max"
        case pressure, humidity
    }
}

// MARK: - Sys
struct Sys: Codable {
    let type, id: Int?
    let country: String?
    let sunrise, sunset: Int?
}

// MARK: - Weather
struct Weather: Codable {
    let id: Int?
    let main, weatherDescription, icon: String?

    enum CodingKeys: String, CodingKey {
        case id, main
        case weatherDescription = "description"
        case icon
    }
}

// MARK: - Wind
struct Wind: Codable {
    let speed: Double?
    let deg: Int?
}

// MARK: -5 Days forecast Model Start
struct ForecastModel: Codable {
    let cod: String?
    let message, cnt: Int?
    let list: [ListModel]?
    //let city: City?
}
struct ListModel: Codable,Identifiable{
    var id = UUID()
    let dt: Int?
    let main: Main?
    let weather: [Weather]?
    let clouds: Clouds?
    let wind: Wind?
    let visibility:Int?
    let pop:Double?
    let sys: Sys?
    let dtTxt: String?

    enum CodingKeys: String, CodingKey {
        case dt, main, weather, clouds, wind, visibility, pop, sys
        case dtTxt = "dt_txt"
    }
}




/*
 
 let object = try? JSONSerialization.jsonObject(with: data) as? [String:Any]
 if let dic = object {
     let name = dic["name"] as! String
     let visibility = dic["visibility"] as! Int
     weatherDataSets.setValue(name, forKey: "name")
     weatherDataSets.setValue(visibility, forKey: "visibility")
     if let wind = dic["wind"] as? [String:Any]{
         let sped = wind["speed"] as! Double
         weatherDataSets.setValue(sped, forKey: "speed")
     }
     if let icon = dic["weather"] as? [String:Any]{
         let weatherIcon = icon["icon"] as! String
         weatherDataSets.setValue(weatherIcon, forKey: "icon")
     }
     
     if let weather = dic["main"] as? [String:Any]{
         let temp = self.convertKalvinToCelsius(value: weather["temp"] as! Double)
         weatherDataSets.setValue(temp, forKey: "temp")
         let tempMax = self.convertKalvinToCelsius(value: weather["temp_max"] as! Double)
         weatherDataSets.setValue(tempMax, forKey: "temp_max")
         let tempMin = self.convertKalvinToCelsius(value: weather["temp_min"] as! Double)
         weatherDataSets.setValue(tempMin, forKey: "temp_min")
         let humidity = weather["humidity"] as! Double
         weatherDataSets.setValue(humidity, forKey: "humidity")
     }
     
     
 }
 */
