//
//  WeatherAppApp.swift
//  WeatherApp
//
//  Created by Simon Ibrahim on 19/05/2022.
//

import SwiftUI

@main
struct WeatherAppApp: App {
    var body: some Scene {
        WindowGroup {
            MainWeatherView()
        }
    }
}
